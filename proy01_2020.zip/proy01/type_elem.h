#ifndef _TYPE_ELEM_H
#define _TYPE_ELEM_H

/* Type for elements */
typedef int type_elem;

#endif
